$('document').ready(function(){
	var mapObject = L.map('fscaMap').setView([40.585258, -105.084419], 13);	
	
	// uncomment additional layers from standardLayers
	// variable to display them.

	var streets = new L.esri.basemapLayer('Streets');
    var imagery= new L.esri.basemapLayer('Imagery');
    var imagelabels = new L.esri.basemapLayer('ImageryLabels');
    var imagestreets = new L.esri.basemapLayer('ImageryTransportation');
    var fullimagery = new L.layerGroup([imagery, imagelabels, imagestreets])
    var topo = new L.esri.basemapLayer('Topographic');

          
    var standardLayers = [streets /*, imagery, imagelabels, imagestreets, fullimagery, streets, topo*/];
    _.forEach(standardLayers, function(layer){
      layer.addTo(mapObject);
    });

	
	// default polyline styles. additional options listed here:
	// http://leafletjs.com/reference.html#path-options
	var bike_route_options = {
		color: '#4169e1',
		weight: 1,
		opacity: 0.5
	}

	// iterates over routes from routes.js bike_routes and 
	// adds them to map.
	_.forEach(bike_routes, function(route){
		var routeLine = L.polyline(route, bike_route_options);
		routeLine.addTo(mapObject);
	})

	// auto-zooms map to a level where all routes show simultaneously
	mapObject.fitBounds(bike_routes);
});
